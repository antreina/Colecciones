package com.example.colecciones

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast


class MainActivity : AppCompatActivity() {

    lateinit var txt:EditText
    lateinit var txv:TextView
    lateinit var txt2:EditText
    var contactos= mutableMapOf("CONTACTO" to listOf("NUMERO"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txt=findViewById(R.id.edtxt)
        txt2=findViewById(R.id.edtxt2)
        txv=findViewById(R.id.txtV)

    }

    fun insertar(view: View) {

        val txt1: String=txt.text.toString()
        val tx2: String=txt2.text.toString()
        contactos.put(txt1,listOf(tx2))
        Toast.makeText(this, "Contacto ingresado con exito", Toast.LENGTH_SHORT).show()
        txv.setText(""+ contactos)
    }

    fun consultar(view: View){
        val txt1: String=txt.text.toString()
        contactos[txt1]
        txv.setText("" + txt1 + contactos[txt1])

    }

    fun eliminar(view: View){
        val txt1: String=txt.text.toString()
        contactos.remove(txt1)
        Toast.makeText(this, "ha eliminado el contacto", Toast.LENGTH_SHORT).show()
        txv.setText(""+ contactos)
    }

    fun mostrar(view: View){
        val txt1: String=txt.text.toString()
        txv.setText(""+ contactos)
    }
}